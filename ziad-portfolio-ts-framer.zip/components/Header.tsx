import Image from 'next/image'
import { motion } from 'framer-motion'

const Header = () => {
  return (
    <motion.header initial={{opacity:0, y:8}} animate={{opacity:1, y:0}} transition={{duration:0.5}} className="flex items-center gap-6 bg-white p-6 rounded-2xl shadow-md">
      <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-indigo-400 flex items-center justify-center bg-indigo-50">
        <Image src="/profile.jpg" alt="Ziad El Bakry" width={96} height={96} />
      </div>
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Ziad Mamdouh Mohamed El Bakry</h1>
        <p className="text-sm text-indigo-600">Full-Stack Developer — AI & Robotics enthusiast</p>
        <div className="mt-2 text-sm space-x-4">
          <a href="mailto:zezomamdouh6@gmail.com" className="underline text-gray-700 hover:text-indigo-600">zezomamdouh6@gmail.com</a>
          <span>•</span>
          <a href="tel:+201129650192" className="underline text-gray-700 hover:text-indigo-600">+20 112 965 0192</a>
        </div>
      </div>
    </motion.header>
  )
}

export default Header
