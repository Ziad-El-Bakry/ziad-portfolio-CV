Place your profile image as 'profile.jpg' and your CV as 'Ziad-El-Bakry-CV.pdf' in this folder.
